# Sistema de Cotizaciones Django

Sistema web para generar cotizaciones y recibos desarrollado en Django con Bootstrap.

## Características

- ✅ CRUD completo para Usuarios, Clientes, Proveedores y Productos
- ✅ Sistema de cotizaciones con items
- ✅ Generación de PDF profesionales
- ✅ Interfaz responsive con Bootstrap 5
- ✅ Autenticación de usuarios
- ✅ Búsqueda y paginación
- ✅ Validaciones de formularios

## Instalación

1. **Crear entorno virtual:**
\`\`\`bash
python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate
\`\`\`

2. **Instalar dependencias:**
\`\`\`bash
pip install -r requirements.txt
\`\`\`

3. **Configurar base de datos:**
\`\`\`bash
python manage.py makemigrations
python manage.py migrate
\`\`\`

4. **Crear superusuario:**
\`\`\`bash
python manage.py createsuperuser
\`\`\`

5. **Ejecutar servidor:**
\`\`\`bash
python manage.py runserver
\`\`\`

6. **Acceder a la aplicación:**
- Aplicación: http://127.0.0.1:8000/
- Admin: http://127.0.0.1:8000/admin/

## Uso

1. **Registrar usuarios** en el sistema
2. **Crear proveedores** para los productos
3. **Agregar productos** con sus precios
4. **Registrar clientes**
5. **Generar cotizaciones** agregando productos
6. **Exportar a PDF** las cotizaciones

## Estructura del Proyecto

\`\`\`
proyecto/
├── cotizaciones/          # App principal
│   ├── models.py         # Modelos de datos
│   ├── views.py          # Vistas basadas en clases
│   ├── forms.py          # Formularios con validaciones
│   ├── urls.py           # URLs de la app
│   ├── admin.py          # Configuración del admin
│   └── pdf_utils.py      # Utilidades para PDF
├── templates/            # Templates HTML
├── static/              # Archivos estáticos
├── proyecto/            # Configuración del proyecto
├── requirements.txt     # Dependencias
└── manage.py           # Script de Django
\`\`\`

## Tecnologías Utilizadas

- **Backend:** Django 4.2
- **Frontend:** Bootstrap 5, HTML5, CSS3, JavaScript
- **Base de datos:** SQLite (desarrollo)
- **PDF:** ReportLab
- **Icons:** Bootstrap Icons

## Funcionalidades Principales

### Dashboard
- Estadísticas generales
- Accesos rápidos
- Cotizaciones recientes

### Gestión de Clientes
- Lista con búsqueda y paginación
- Formularios de creación/edición
- Validaciones personalizadas

### Gestión de Proveedores
- CRUD completo
- Relación con productos

### Gestión de Productos
- Vinculación con proveedores
- Control de precios
- Estado activo/inactivo

### Sistema de Cotizaciones
- Creación de presupuestos y recibos
- Agregado dinámico de productos
- Cálculo automático de totales
- Exportación a PDF profesional

## Autor

Sistema desarrollado basado en el proyecto original de Cdruetta.
