# Configuraciones para desarrollo local
# Copia este archivo y renómbralo a local_settings.py para usar configuraciones locales

from .settings import *

# Debug
DEBUG = True

# Base de datos para desarrollo
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Para usar PostgreSQL en desarrollo, descomenta y configura:
# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.postgresql',
#         'NAME': 'cotizaciones_db',
#         'USER': 'tu_usuario',
#         'PASSWORD': 'tu_password',
#         'HOST': 'localhost',
#         'PORT': '5432',
#     }
# }

# Email backend para desarrollo (imprime emails en consola)
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# Configuración de archivos estáticos para desarrollo
STATICFILES_DIRS = [
    BASE_DIR / 'static',
]

# Configuración de media files
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# Configuración de logging para desarrollo
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'root': {
        'handlers': ['console'],
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}

# Configuraciones adicionales para desarrollo
ALLOWED_HOSTS = ['localhost', '127.0.0.1', '0.0.0.0']

# Configuración de caché para desarrollo
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.dummy.DummyCache',
    }
}
