"use client"

import  from "../static/js/main"

export default function SyntheticV0PageForDeployment() {
  return < />
}